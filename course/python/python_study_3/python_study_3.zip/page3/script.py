# Tambahkan parameter untuk print_hand
def print_hand(hand):
    # Gunakan parameter untuk mencetak 'Anda memilih: ___'
    print('Anda memilih:' + hand)

# Panggil print_hand dengan 'Batu'
print_hand('Batu')

# Panggil print_hand dengan 'Kertas'
print_hand('Kertas')
